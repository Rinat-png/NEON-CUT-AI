package com.neoncutai.editor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray

private val NeonCyan = Color(0xFF42E8F5)
private val NeonPurple = Color(0xFF9B5CFF)
private val DarkBg = Color(0xFF0B0B14)
private val DarkCard = Color(0xFF171727)
private val LightBg = Color(0xFFF4F5FA)
private val LightCard = Color(0xFFFFFFFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            NeonCutApp(
                loadProjects = { readProjects() },
                saveProjects = { writeProjects(it) }
            )
        }
    }

    private fun readProjects(): List<String> {
        val raw = getSharedPreferences("neon_cut", MODE_PRIVATE).getString("projects", "[]") ?: "[]"
        return try {
            val array = JSONArray(raw)
            (0 until array.length()).map { array.getString(it) }
        } catch (_: Exception) { emptyList() }
    }

    private fun writeProjects(projects: List<String>) {
        val array = JSONArray()
        projects.forEach { array.put(it) }
        getSharedPreferences("neon_cut", MODE_PRIVATE).edit().putString("projects", array.toString()).apply()
    }
}

@Composable
private fun NeonCutApp(loadProjects: () -> List<String>, saveProjects: (List<String>) -> Unit) {
    var lightTheme by remember { mutableStateOf(false) }
    var showCreateDialog by remember { mutableStateOf(false) }
    var projectName by remember { mutableStateOf("") }
    var selectedProject by remember { mutableStateOf<String?>(null) }
    var showDeleteDialog by remember { mutableStateOf<String?>(null) }
    val projects = remember { mutableStateListOf<String>().apply { addAll(loadProjects()) } }
    val background = if (lightTheme) LightBg else DarkBg
    val card = if (lightTheme) LightCard else DarkCard
    val mainText = if (lightTheme) Color(0xFF191927) else Color.White
    val secondaryText = if (lightTheme) Color(0xFF626276) else Color(0xFFB7B7CE)

    MaterialTheme {
        Surface(Modifier.fillMaxSize(), color = background) {
            if (selectedProject == null) {
                Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("NEON CUT", color = NeonCyan, fontSize = 28.sp, fontWeight = FontWeight.Black)
                            Text("AI  •  VIDEO STUDIO", color = NeonPurple, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Светлая тема", color = secondaryText, fontSize = 11.sp)
                            Switch(checked = lightTheme, onCheckedChange = { lightTheme = it })
                        }
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Твоя монтажная студия", color = mainText, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Text("Создавай проекты и готовься к работе с видео, эффектами, анимированным текстом и локальным ИИ.", color = secondaryText, fontSize = 14.sp)
                            Button(onClick = { showCreateDialog = true }, modifier = Modifier.fillMaxWidth()) { Text("＋ Новый проект") }
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Мои проекты", color = mainText, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.weight(1f))
                        Text("${projects.size}", color = NeonCyan, fontWeight = FontWeight.Bold)
                    }
                    if (projects.isEmpty()) {
                        Card(colors = CardDefaults.cardColors(containerColor = card)) {
                            Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Пока нет проектов", color = mainText, fontWeight = FontWeight.SemiBold)
                                Text("Нажми «Новый проект», чтобы начать.", color = secondaryText, fontSize = 13.sp)
                            }
                        }
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(projects.toList(), key = { it }) { name ->
                                Card(Modifier.fillMaxWidth().clickable { selectedProject = name }, colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(16.dp)) {
                                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Box(Modifier.size(44.dp).background(NeonPurple.copy(alpha = 0.2f), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) { Text("▶", color = NeonCyan, fontSize = 20.sp) }
                                        Column(Modifier.weight(1f).padding(start = 12.dp)) {
                                            Text(name, color = mainText, fontWeight = FontWeight.Bold)
                                            Text("Проект NEON CUT AI", color = secondaryText, fontSize = 12.sp)
                                        }
                                        TextButton(onClick = { showDeleteDialog = name }) { Text("Удалить") }
                                    }
                                }
                            }
                        }
                    }
                    Spacer(Modifier.weight(1f))
                    Text("ЭТАП 1 • ОСНОВА ПРИЛОЖЕНИЯ", color = secondaryText, fontSize = 10.sp)
                }
            } else {
                Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    TextButton(onClick = { selectedProject = null }) { Text("← Все проекты") }
                    Text(selectedProject!!, color = NeonCyan, fontSize = 26.sp, fontWeight = FontWeight.Black)
                    Text("Рабочее пространство проекта", color = secondaryText)
                    Card(colors = CardDefaults.cardColors(containerColor = card)) {
                        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Редактор готовится", color = mainText, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Text("Это первая основа приложения. Импорт видео, таймлайн, предпросмотр, эффекты и экспорт будут добавляться и проверяться отдельными этапами.", color = secondaryText)
                            Text("Запланировано: видео • звук • текст • ИИ", color = NeonCyan)
                        }
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("Новый проект") },
            text = { OutlinedTextField(value = projectName, onValueChange = { projectName = it }, label = { Text("Название проекта") }, singleLine = true) },
            confirmButton = { TextButton(onClick = {
                val name = projectName.trim()
                if (name.isNotEmpty() && name !in projects) {
                    projects.add(0, name); saveProjects(projects.toList()); projectName = ""; showCreateDialog = false
                }
            }) { Text("Создать") } },
            dismissButton = { TextButton(onClick = { showCreateDialog = false }) { Text("Отмена") } }
        )
    }
    if (showDeleteDialog != null) {
        val name = showDeleteDialog!!
        AlertDialog(
            onDismissRequest = { showDeleteDialog = null },
            title = { Text("Удалить проект?") },
            text = { Text("Проект «$name» будет удалён из списка этого прототипа.") },
            confirmButton = { TextButton(onClick = { projects.remove(name); saveProjects(projects.toList()); showDeleteDialog = null }) { Text("Удалить") } },
            dismissButton = { TextButton(onClick = { showDeleteDialog = null }) { Text("Отмена") } }
        )
    }
}
